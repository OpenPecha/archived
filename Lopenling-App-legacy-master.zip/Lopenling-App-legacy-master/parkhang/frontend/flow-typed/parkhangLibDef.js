declare var USER_ID: number;
declare var USER_NAME: string;