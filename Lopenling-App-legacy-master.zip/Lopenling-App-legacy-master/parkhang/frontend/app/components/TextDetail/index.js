export { default } from "./TextDetail";
