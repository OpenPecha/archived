import About from "./About";
import Resources from "./Resources";
import FullTextSearch from "./FullTextSearch";
import Discussion from './Discussions'
export default { About, Resources,  FullTextSearch,Discussion };
