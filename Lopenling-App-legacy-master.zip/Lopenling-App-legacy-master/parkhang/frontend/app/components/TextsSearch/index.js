export { default } from "./TextsSearchContainer";
