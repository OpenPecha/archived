export {default} from './TextDetailContainer'
