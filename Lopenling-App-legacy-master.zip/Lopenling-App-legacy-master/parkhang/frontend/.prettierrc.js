module.exports = {
    printWidth: 80,
    parser: "babel",
    semi: true,
    tabWidth: 4
};