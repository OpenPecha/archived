from django.apps import AppConfig


class DiscourseConfig(AppConfig):
    name = 'discourse'
