<h1 align="center">Lopenling API Docs</h1>

Documentation for Lopening API

### Table Of Content
- [Alignments](/Lopenling-App/api/alignments)
- [Featured Texts](/Lopenling-App/api/featured-texts)
- Discourse
- Texts
