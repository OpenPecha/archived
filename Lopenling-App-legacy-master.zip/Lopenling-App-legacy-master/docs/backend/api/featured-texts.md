# Featured Text List

**Endpoint** GET `/api/texts/featured/`

**Schema**

```json
[
  {
    "text": 139,
    "title": "བྱང་ཆུབ་སེམས་དཔའི་སྤྱོད་པ་ལ་འཇུག་པ་བཞུགས་སོ།",
    "order": 1,
    "description": null
  }
]
```
