<h1 align="center">Lopenling Page Information</h1>

Documentation for Lopening Frontend Pages

## Header Links

- `Texts` : list of all the featured text
- `Editor`: Lopenling main annotation editor page
- `Translate` : Translate Toggle between Ti and En
- `Login` : Login and Signup link
- `Theme` : Selection between `dark mode` and `light mode`

### Texts Page Feature

- `filter` : filter feature text on the basis of condition provided in filter section

### Editor Page Feature Buttons

1. `Text Selector`:
2. `Version Selector`:
3. `Refresh Button`:
4. `Find Term`:
5. `Settings`:
6. `Table of Content`:
7. `SpeedDial `
   - `Split Window`
   - `Share`
   - `Link Panel`
   - `Annotate`
