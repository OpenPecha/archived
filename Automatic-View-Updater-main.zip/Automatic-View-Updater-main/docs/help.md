
# Need help or have questions?

- File an [issue](add link).
- Join our [Discord](https://discord.com/invite/7GFpPFSTeA) and ask there.
- Email us at openpecha[at]gmail[dot]com.
