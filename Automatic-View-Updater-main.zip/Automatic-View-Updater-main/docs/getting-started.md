# Getting started

Intro

## 1. Prerequisites

- Python version
- _Dependency 1_

## 2. Installation

1. _Write the step here._
2. _Write the step here._

## 3. Configuration

1. _Write the step here._
2. _Write the step here._

## 4. Short how-to

1. _Write the step here._
2. _Write the step here._

## 5. Troubleshooting

_Add any known issues and solutions_

Get more help [here](help.md).
