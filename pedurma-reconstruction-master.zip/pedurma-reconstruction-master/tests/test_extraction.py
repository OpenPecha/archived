import sys

sys.path.append("../")
import re
from pathlib import Path

import test_extraction


def test_extraction():
    