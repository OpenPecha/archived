# nalanda-notes
yet another nalanda notes repo

# Installation
```
git clone https://github.com/Esukhia/nalanda-notes.git
cd nalanda-notes
pip install -r requirements.txt
pip install -e .
```
