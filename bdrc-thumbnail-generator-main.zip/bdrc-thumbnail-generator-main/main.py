from image_downloader import BDRCImageDownloader,_mkdir,DATA_DIR,BASE_PATH
import github_utils
from pathlib import Path
import os
import csv
import shutil
import csv
from horology import timed



def download_image(work_id):
    work_path = DATA_DIR+"/"+work_id
    downloader = BDRCImageDownloader(bdrc_scan_id=work_id, output_dir=Path(DATA_DIR))
    downloader.download()
    return work_path

def get_readme(work_id,no_of_unique_images):
    work_id = f"|Work Id | {work_id}"
    Table = "| --- | --- "
    img_nos = f"|Target image number | {no_of_unique_images}"

    readme = f"{work_id}\n{Table}\n{img_nos}"
    return readme


def publish_repo(repo_name, work_id, no_of_unique_images,asset_paths):
    token = os.getenv("GITHUB_TOKEN")
    read_me = get_readme(work_id,no_of_unique_images)
    local_repo = _mkdir(BASE_PATH / repo_name)
    unique_image_folder = _mkdir(local_repo / f"{work_id}-{no_of_unique_images:03}")
    Path(unique_image_folder / "example").write_text("example")
    Path(local_repo / "readme.md").write_text(read_me)
    github_utils.github_publish(
        local_repo,
        message="initial commit",
        not_includes=[],
        layers=[],
        org="MonlamAI",
        token=token,
        description=work_id
       )
    release_link = github_utils.create_release(
        repo_name,
        prerelease=False,
        asset_paths=asset_paths, 
        org="MonlamAI",
        token=token

    )
    shutil.rmtree(BASE_PATH / repo_name)
    return release_link


def update_catalog(work_id,repo_name,release_link):
    with open(f"catalog.csv",'a') as f:
        writer = csv.writer(f)
        writer.writerow([work_id,repo_name,release_link])


def zip_dir(work_id):
    zip_file_path = f"{DATA_DIR}/zip"
    Path(zip_file_path).mkdir(exist_ok=True, parents=True)
    shutil.make_archive(f"{zip_file_path}/{work_id}", 'zip', f"{DATA_DIR}/{work_id}")
    return f"{zip_file_path}/{work_id}.zip"


@timed(unit='s', name="Compute work size: ")
def get_work_size(work_id):
    number_of_images = len(list(Path(f'{DATA_DIR}/{work_id}').iterdir()))
    return number_of_images
    
def get_number_of_unique_images(dataset_type, no_of_imgs):
    if dataset_type == "LA":
        if no_of_imgs >10000:
            no_of_unique_imgs = 100
        elif no_of_imgs < 1000:
            no_of_unique_imgs = 10
        else:
            no_of_unique_imgs = no_of_imgs // 100
    elif dataset_type == "PD":
        if no_of_imgs >10000:
            no_of_unique_imgs = 500
        elif no_of_imgs < 1000:
            no_of_unique_imgs = 10
        else:
            no_of_unique_imgs = no_of_imgs // 50
    return no_of_unique_imgs

def main(work_id,dataset_type):
    repo_name = f"OCR_{dataset_type}{'{:05d}'.format(id)}"
    work_path = download_image(work_id)
    zip_file = zip_dir(work_id)
    img_nos = get_work_size(work_id)
    number_of_unique_images = get_number_of_unique_images(dataset_type, img_nos)
    release_link = publish_repo(repo_name,work_id,number_of_unique_images,asset_paths=[zip_file])
    update_catalog(work_id,repo_name,release_link)
    print(f"DONE {work_id}")
    shutil.rmtree(work_path)
    shutil.rmtree(Path(zip_file).parent)

        
def get_work_ids(csv_path):
    work_ids = []
    with open(csv_path, 'r') as csvfile:
        csvreader = csv.reader(csvfile)
        for row in csvreader:
            work_ids.append(row[0])
    return work_ids


if __name__ == "__main__":
    id = int("394")
    dataset_type = "LA"
    work_ids = get_work_ids("work_report.csv")
    for work_id in work_ids[1:]:
        main(work_id, dataset_type)
        id+=1
