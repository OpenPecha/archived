# google-ocr-postprocessing
Post processing google OCR output
